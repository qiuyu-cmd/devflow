# -*- coding: utf-8 -*-
"""
工具能力注册 (Capabilities) —— 只登记"有什么工具, 函数在哪"。
不含任何安全信息 (scope/resource/risk 已在 policy.py 的 TOOL_REGISTRY 独立声明)。

这就是"能力"与"授权"分离: 工具函数是"傻的", 不知道自己的权限边界;
权限边界由策略决策点 (PDP, 见 policy.py) 在运行时决定。
"""


# ---------- 工具实现: 纯函数, 只负责"会做什么" ----------
def _query_order(order_id: str):
    # 真实项目中查询数据库 / 调用订单 API
    return f"订单 {order_id} 状态: 已支付, 金额 299.00 元"


def _refund_order(order_id: str, amount: float):
    # 高危操作, 涉及资金
    return f"订单 {order_id} 已退款 {amount} 元"


def _notify_user(user_id: str, text: str):
    return f"已向用户 {user_id} 发送通知: {text}"


def _summarize_text(text: str, max_len: int = 100):
    # L0: 无外部影响, 纯文本能力
    return f"(摘要) {text[:max_len]}..."


def _draft_note(title: str, content: str):
    # L2: 低风险写入, 在工作区创建草稿文件
    return f"已在工作区创建草稿: {title}.md ({len(content)} 字符)"


def _write_file(path: str, content: str):
    # L2: 写入工作区文件 (演示文档 Rego 场景)
    return f"已写入文件: {path} ({len(content)} 字符)"


def _delete_document(doc_id: str):
    # L4: 破坏性动作, 删除文档 (强制人工确认 + 可回滚标记)
    return f"文档 {doc_id} 已标记删除 (可回滚, 保留 30 天)"


# ---------- 能力注册表: 只绑定 名字 -> (描述, 函数) ----------
CAPABILITIES = {
    "order.query":    {"desc": "按订单号查询订单状态",   "fn": _query_order},
    "order.refund":   {"desc": "按订单号执行退款",       "fn": _refund_order},
    "notify.user":    {"desc": "向指定用户发送通知",     "fn": _notify_user},
    "text.summarize": {"desc": "对文本做摘要总结",       "fn": _summarize_text},
    "note.draft":     {"desc": "在工作区创建草稿文件",   "fn": _draft_note},
    "write_file":     {"desc": "写入工作区文件",         "fn": _write_file},
    "doc.delete":     {"desc": "删除一份文档",           "fn": _delete_document},
}


def get_fn(tool_name: str):
    """按工具名取实现函数, 不存在返回 None"""
    cap = CAPABILITIES.get(tool_name)
    return cap["fn"] if cap else None


def list_capabilities():
    """能力清单, 可发给 LLM 做 Function Calling 描述"""
    return [{"name": n, "description": c["desc"]} for n, c in CAPABILITIES.items()]
