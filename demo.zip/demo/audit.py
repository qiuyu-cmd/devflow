# -*- coding: utf-8 -*-
"""
审计日志: 记录每一次工具调用的完整上下文 (对齐文档"审计闭环")
每条记录包含: TraceID / 事件 / 工具 / 参数 / 审批结果 / 执行结果
"""
import json
from datetime import datetime


class AuditLogger:
    def __init__(self):
        self.events = []

    def log(self, event: dict):
        record = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            **event,
        }
        self.events.append(record)
        print(f"[AUDIT] {json.dumps(record, ensure_ascii=False)}")

    def dump(self):
        return list(self.events)

    def __len__(self):
        return len(self.events)
