# -*- coding: utf-8 -*-
"""
六级全流程速览 (L0-L5) —— 对齐两层模型:

  第 1 层 授权 (PDP): 布尔 allow/deny (scope / 专属规则 / ABAC)
  第 2 层 流程 (Agent/PEP, 按工具 L 危险度标签):
      L0/L1/L2 -> 直接执行 (auto)
      L3/L4    -> 人工确认 (approval)
      L5       -> 多因素 + 双人复核 (mfa)

用 AutoApprove 自动批准, 一次跑完看 L0-L5 逐级差异, 不卡输入。
想看真实人工/多因素审批, 请运行 main.py (交互式)。

运行: python demo_levels.py
"""
import sys, time
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from audit import AuditLogger
from approval import ApprovalHandler
from agent import Agent
from policy import LEVELS, TOOL_REGISTRY


class AutoApprove(ApprovalHandler):
    """演示用: 自动批准人工审批与多因素审批"""
    def request_approval(self, action, reason):
        return True
    def request_mfa(self, action, reason):
        return True


# 每个等级挑一个代表工具
LEVEL_TOOL = {
    "L0": ("text.summarize", {"text": "这是一段很长的产品说明……", "max_len": 20}),
    "L1": ("order.query",    {"order_id": "A1001"}),
    "L2": ("note.draft",     {"title": "周报草稿", "content": "本周完成…"}),
    "L3": ("notify.user",    {"user_id": "u_42", "text": "您的订单已受理"}),
    "L4": ("doc.delete",     {"doc_id": "doc-771"}),
    "L5": ("order.refund",   {"order_id": "A1001", "amount": 99.0}),
}


def run():
    audit = AuditLogger()
    approval = AutoApprove()
    agent = Agent(audit, approval)

    # 授予用户全部工具的 scope, 排除"权限不足", 只看等级/流程差异
    all_scopes = {c["scope"] for c in TOOL_REGISTRY.values()}
    agent.set_session_user({"id": "alice", "groups": ["engineering", *all_scopes],
                            "expires_at_ns": time.time_ns() + 10**12})

    print("六级权限全流程速览 (L0 -> L5), 已授权全部工具")
    print(f"{'级别':<5}{'动作类型':<12}{'处理流程':<16}{'工具':<16}{'执行'}")
    print("-" * 64)

    for lv in sorted(LEVELS.keys()):
        info = LEVELS[lv]
        tool, args = LEVEL_TOOL[lv]
        r = agent.execute_tool(tool, args, "session-000", "trace-000")
        status = "OK(执行)" if "result" in r else f"拒绝: {r.get('error')}"
        print(f"{lv:<5}{info['type']:<12}{info['handling']:<16}{tool:<16}{status}")
        print("-" * 64)

    print("\n工具 -> 等级 -> 流程")
    for name, c in TOOL_REGISTRY.items():
        print(f"  {name:<16} L{c['level']}  {LEVELS[c['level']]['handling']}")


run()
