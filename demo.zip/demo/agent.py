# -*- coding: utf-8 -*-
"""
Agent 主逻辑 —— 扮演 PEP (Policy Enforcement Point)。

两层职责 (与 PDP 分离):
  1) 授权: 调用 policy.decide() 拿布尔 allow, allow=false 就拒绝。
     对应文档: if not decision["allow"]: raise ToolAuthorizationError(...)
  2) 流程: allow 通过后, 查工具的 L 危险度标签, 决定走什么审批流程:
        flow=auto      -> 直接执行
        flow=approval  -> 人工确认后才执行
        flow=mfa       -> 多因素审批 + 分权 (双人复核) 后才执行
  其中"允不允许"是 PDP 算的布尔;"L 分级流程"是 Agent 侧按工具标签做的。
"""
from tools import get_fn
from policy import decide, TOOL_REGISTRY, LEVELS
from policy_context import PolicyContext
from audit import AuditLogger
from approval import ApprovalHandler


class Agent:
    def __init__(self, audit: AuditLogger, approval: ApprovalHandler):
        self.audit = audit
        self.approval = approval
        # 会话用户 (真实项目由 OIDC token 解析): id / groups / expires_at_ns
        self.session_user = {
            "id": "alice",
            "groups": [],            # 这里可放组织组, 如 ["engineering"]
            "expires_at_ns": 0,
        }
        # 运行时事实 (ABAC) 由平台注入, Agent 只读
        self.policy_context = PolicyContext()

    def set_session_user(self, user: dict):
        self.session_user = dict(user)

    def _flow_of(self, tool_name: str) -> str:
        """查工具的 L 危险度标签 -> 返回流程 (auto/approval/mfa)"""
        level = TOOL_REGISTRY.get(tool_name, {}).get("level", "L0")
        return LEVELS.get(level, {}).get("flow", "auto")

    def execute_tool(self, tool_name: str, args: dict, session_id: str,
                     trace_id: str = "trace-000", llm_claims: dict | None = None):
        # 取平台注入的环境快照 (只读), 忽略 LLM 伪造的 claims
        env_snapshot = self.policy_context.snapshot()
        if llm_claims:
            self.audit.log({"trace_id": trace_id, "session_id": session_id,
                            "event": "llm_claim_ignored",
                            "claimed_fields": sorted(llm_claims.keys())})

        # ---- 能力白名单 (函数是否存在) ----
        fn = get_fn(tool_name)
        if not fn:
            self.audit.log({"trace_id": trace_id, "session_id": session_id,
                            "event": "tool_not_found", "tool": tool_name})
            return {"error": f"未知工具: {tool_name} (不在能力清单内)"}

        # ---- 第 1 层: 授权 (PDP 算布尔 allow) ----
        decision = decide(self.session_user, self.session_user.get("groups", []),
                          tool_name, args, env_snapshot)
        if not decision.allow:
            # 对应文档: if not decision["allow"]: raise ToolAuthorizationError
            self.audit.log({"trace_id": trace_id, "session_id": session_id,
                            "event": "permission_denied", "tool": tool_name,
                            "reason": decision.reason,
                            "rule": decision.rule})
            return {"error": decision.reason}

        # ---- 第 2 层: 流程 (按工具 L 危险度标签决定审批) ----
        flow = self._flow_of(tool_name)
        level = TOOL_REGISTRY.get(tool_name, {}).get("level", "L0")
        action_key = f"{session_id}:{tool_name}:{hash(frozenset(args.items()))}"

        if flow == "approval":
            # L3/L4: 人工确认
            if not self.approval.is_approved(action_key):
                info = LEVELS[level]
                if not self.approval.request_approval(
                        f"{tool_name}({args})",
                        f"{info['type']} ({info['handling']})"):
                    self.audit.log({"trace_id": trace_id, "session_id": session_id,
                                    "event": "approval_rejected", "tool": tool_name,
                                    "args": args})
                    return {"error": "操作已被审批人拒绝"}

        if flow == "mfa":
            # L5: 多因素审批 + 分权 (双人复核)
            if not self.approval.is_mfa_approved(action_key):
                info = LEVELS[level]
                if not self.approval.request_mfa(
                        f"{tool_name}({args})",
                        f"{info['type']} ({info['handling']})"):
                    self.audit.log({"trace_id": trace_id, "session_id": session_id,
                                    "event": "mfa_rejected", "tool": tool_name,
                                    "args": args})
                    return {"error": "操作未通过多因素审批/分权复核"}

        # ---- 执行 (PRE-EXEC 审计) ----
        self.audit.log({"trace_id": trace_id, "session_id": session_id,
                        "event": "tool_call", "tool": tool_name, "args": args,
                        "allowed": True, "level": level, "flow": flow})
        result = fn(**args)

        # ---- POST-EXEC 审计 ----
        self.audit.log({"trace_id": trace_id, "session_id": session_id,
                        "event": "tool_result", "tool": tool_name, "result": result})
        return {"result": result}
