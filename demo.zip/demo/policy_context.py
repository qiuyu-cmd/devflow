# -*- coding: utf-8 -*-
"""
运行时事实 / 动态上下文 (ABAC) —— 对应文档"动态上下文的授权"。

关键安全语义:
  environment 是"策略之外的运行时事实", 由【运行时平台】写入 (this module 模拟),
  LLM / Agent 只能"读"它并作为 input 传给策略, 不能"写"它。
  这正是防止 LLM 伪造运行时事实 (例如把 travel_velocity 改成很小) 来绕过风控的关键。

真实生产里这些字段由平台注入:
  - now_ns                        由 OPA / NTP 时间源提供
  - user_ip_geo                   由反向代理 / 网关注入
  - session_travel_velocity_kmh   由 session service 计算 (异地登录风控)
  - session_start_ns              会话开始时间
"""
import time


class PolicyContext:
    """扮演"运行时平台"：生成并保管一份只读的 environment 快照。"""

    def __init__(self, ip_geo="CN-Shanghai", travel_velocity_kmh=0.0,
                 session_start_ns=None):
        # 这些字段在平台层生成, Agent 只读, 不允许改
        self._env = {
            "now_ns": time.time_ns(),                          # 平台时间 (真实由 NTP)
            "user_ip_geo": ip_geo,                             # 注入的地理位置
            "session_travel_velocity_kmh": travel_velocity_kmh,  # 会话移动速度
            "session_start_ns": session_start_ns or time.time_ns(),
        }

    # ---- 只读访问: 返回不可变的快照, Agent 能读不能写 ----
    def snapshot(self) -> dict:
        # 返回 dict 副本, 外层修改不影响内部; 语义上这是"只读给策略"
        return dict(self._env)

    # ---- 平台侧更新 (只有平台能调用, 表示"运行时事实"变了) ----
    # 兼容传入完整键名 session_travel_velocity_kmh 或简写 travel_velocity_kmh
    def update(self, **kwargs):
        if "travel_velocity_kmh" in kwargs and "session_travel_velocity_kmh" not in kwargs:
            kwargs["session_travel_velocity_kmh"] = kwargs.pop("travel_velocity_kmh")
        self._env.update(kwargs)
