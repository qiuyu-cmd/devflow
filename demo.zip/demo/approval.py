# -*- coding: utf-8 -*-
"""
审批处理器: L3/L4 中高风险操作由代码强制拦截并请求人工确认,
L5 资金/法律/安全关键操作升级为多因素审批 + 分权执行 (双人确认)。
生产环境应替换为异步审批 API (企微/钉钉/飞书/自建工单), Agent 等待回调。
这里用 input() 模拟真人审批, 并缓存已批准的动作避免重复询问。
"""
class ApprovalHandler:
    def __init__(self):
        self.approved_actions = set()
        self.mfa_approved_actions = set()

    def request_approval(self, action: str, reason: str) -> bool:
        # 生产环境: 创建审批单并等待异步回调, 而非阻塞式 input
        answer = input(f"[APPROVAL] 请求审批: {action}\n"
                       f"           原因: {reason}\n"
                       f"           是否批准? (y/n): ").strip().lower()
        approved = answer == "y"
        if approved:
            self.approved_actions.add(action)
        return approved

    def request_mfa(self, action: str, reason: str) -> bool:
        """多因素审批 + 分权执行: 需要两个独立审批人都批准 (双人复核)。

        模拟 L5"资金/法律/安全关键"的分权语义: 一个审批人不够,
        必须第二个独立角色复核通过才放行。
        """
        for approver in ("审批人A(业务)", "审批人B(安全)"):
            answer = input(f"[MFA] {action}\n"
                           f"     原因: {reason}\n"
                           f"     {approver} 是否批准? (y/n): ").strip().lower()
            if answer != "y":
                return False
        self.mfa_approved_actions.add(action)
        return True

    def is_approved(self, action: str) -> bool:
        return action in self.approved_actions

    def is_mfa_approved(self, action: str) -> bool:
        return action in self.mfa_approved_actions
