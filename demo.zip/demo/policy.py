# -*- coding: utf-8 -*-
"""
策略决策点 (PDP, Policy Decision Point) —— 只负责【授权判定】。

职责: 回答"这个用户调这个工具访问这个资源, 被允许吗?"
输出: 布尔 allow (true/false), 没有第三态。
      if not allow -> 拒绝 (由 Agent/PEP 执行)

对应文档:
    decision = opa_client.evaluate("<package>", input=policy_input)
    if not decision["allow"]:
        raise ToolAuthorizationError(...)

本文件用纯 Python 模拟 OPA + Rego:
  - build_policy_input(): 构造 policy_input (session/tool/resource/environment)
  - decide(): 像 OPA 对 input 跑 Rego 那样逐条评估规则, 算出 allow

注意: 这里【不掺】L0-L5 分级。分级是"工具的静态危险度标签" (见 TOOL_REGISTRY),
      由 Agent/PEP 在执行前决定走多严的审批流程, 与"允不允许"是两层。
"""
from typing import Optional
from dataclasses import dataclass


# ---------- L0-L5 分级定义表 ----------
# 这是"操作风险分级", 作为工具的静态标签存在, 供 Agent/PEP 决定审批流程。
# 等级 | 动作类型         | 推荐处理(流程)
# L0   | 无外部影响       | 可直接执行
# L1   | 只读查询         | 记录日志, 可自动执行
# L2   | 低风险写入       | 限定范围, 自动或弱确认
# L3   | 可见外部动作     | 确认对象和内容
# L4   | 破坏性或敏感动作 | 强制人工确认, 可回滚
# L5   | 资金/法律/安全关键| 多因素审批, 分权执行
LEVELS = {
    "L0": {"type": "无外部影响",       "handling": "可直接执行",     "flow": "auto"},
    "L1": {"type": "只读查询",         "handling": "记录日志, 可自动执行", "flow": "auto"},
    "L2": {"type": "低风险写入",       "handling": "限定范围, 自动或弱确认", "flow": "auto"},
    "L3": {"type": "可见外部动作",     "handling": "确认对象和内容",  "flow": "approval"},
    "L4": {"type": "破坏性或敏感动作", "handling": "强制人工确认, 可回滚", "flow": "approval"},
    "L5": {"type": "资金/法律/安全关键", "handling": "多因素审批, 分权执行", "flow": "mfa"},
}


# ---------- 工具注册表 (TOOL_REGISTRY): 定义工具的 capability + 危险度标签 ----------
# 每个工具: scope(所需权限) / resource(资源边界) / side_effect(副作用) / level(危险度)
TOOL_REGISTRY = {
    "text.summarize": {"scope": "text:summarize", "resource": "input:text",
                       "side_effect": "none",     "level": "L0"},
    "order.query":    {"scope": "order:read",     "resource": "order/*",
                       "side_effect": "none",     "level": "L1"},
    "note.draft":     {"scope": "note:write",     "resource": "workspace/*",
                       "side_effect": "local",    "level": "L2"},
    "write_file":     {"scope": "fs.write",       "resource": "/workspace/*",
                       "side_effect": "local",    "level": "L2"},
    "notify.user":    {"scope": "notify:send",    "resource": "user/*",
                       "side_effect": "external", "level": "L3"},
    "doc.delete":     {"scope": "doc:delete",     "resource": "doc/*",
                       "side_effect": "external", "level": "L4"},
    "order.refund":   {"scope": "order:refund",   "resource": "order/*",
                       "side_effect": "external", "level": "L5"},
}


# ---------- Policy Input 构造 ----------
def build_policy_input(user, tool_name: str, args: dict,
                       env: Optional[dict] = None) -> dict:
    """组装提交给策略评估的结构化 input (对应文档的 policy_input)。"""
    contract = TOOL_REGISTRY.get(tool_name, {})
    return {
        "session": {
            "user": user.get("id"),
            "groups": list(user.get("groups", [])),
            "expires_at_ns": user.get("expires_at_ns", 0),
        },
        "tool": {
            "name": tool_name,
            "scope": contract.get("scope", ""),
        },
        "resource": {
            "path": args.get("path", args.get("resource", contract.get("resource", ""))),
            "type": contract.get("resource", ""),
        },
        "environment": env or {},   # 平台注入的运行时事实, LLM 只读
    }


def _startswith(s, prefix):
    return isinstance(s, str) and s.startswith(prefix)


# ---------- 授权规则 (模拟 Rego 规则集) ----------
# 每条规则: name + 条件(input)->bool。逐条评估, 命中即得对应结论。
# 结果只有 allow=true / allow=false, 没有审批等中间态。
# 注意: 有"专属复合规则"的工具 (如 write_file 的 R4/R5) 优先于通用 RBAC,
#       因为其专属规则内部已包含 scope/组/资源/时间等全部条件。
RULES = [
    # R1: 工具白名单
    {
        "name": "tool_allowlist",
        "cond": lambda pi: pi["tool"]["name"] not in TOOL_REGISTRY,
        "allow": False,
        "reason": "tool 不在授权契约/白名单内",
    },
    # R2: write_file 专属复合规则 (对应文档 Rego 四条件, allow)
    #     只有当 组=engineering AND scope=fs.write AND 路径在/workspace/ AND token未过期 才允许
    #     对应文档: default allow=false; allow { 四条件 }
    {
        "name": "write_file_engineering_scope_path_ttl",
        "cond": lambda pi: (
            pi["tool"]["name"] == "write_file"
            and "engineering" in pi["session"]["groups"]
            and pi["tool"]["scope"] == "fs.write"
            and _startswith(pi["resource"]["path"], "/workspace/")
            and pi["environment"].get("now_ns", 0) < pi["session"]["expires_at_ns"]
        ),
        "allow": True,
        "reason": "engineering 组 + fs.write + 路径在/workspace/ + token 未过期 -> allow",
    },
    # R3: write_file 其余情况一律拒绝 (default deny)
    {
        "name": "write_file_default_deny",
        "cond": lambda pi: pi["tool"]["name"] == "write_file",
        "allow": False,
        "reason": "write_file 未满足 engineering+scope+path+ttl (default deny)",
    },
    # R4: 通用最小权限 (RBAC) —— 仅对无专属规则的其余工具生效
    {
        "name": "scope_check",
        "cond": lambda pi: pi["tool"]["scope"] not in pi["session"]["groups"],
        "allow": False,
        "reason": "权限不足: 缺少所需 scope",
    },
    # R5: ABAC 动态上下文风控 —— L4/L5 高危在异地高速移动时拒绝
    {
        "name": "abac_risk",
        "cond": lambda pi: (
            _lvl(pi["tool"]["name"]) in ("L4", "L5")
            and pi["environment"].get("session_travel_velocity_kmh", 0.0) > 800.0
        ),
        "allow": False,
        "reason": "ABAC: 高危操作在异常动态上下文中被拒绝 (风控)",
    },
    # R6: 兜底 —— 已通过白名单+scope+无ABAC的工具, 默认允许
    {
        "name": "default_allow",
        "cond": lambda pi: True,
        "allow": True,
        "reason": "通过授权规则",
    },
]


def _lvl(tool_name):
    return TOOL_REGISTRY.get(tool_name, {}).get("level", "L0")


@dataclass
class Decision:
    """PDP 产出的决策 —— 只有布尔 allow"""
    allow: bool
    reason: str = ""
    rule: Optional[str] = None


def decide(user, user_scopes, tool_name: str, args: dict | None = None,
           env: Optional[dict] = None) -> Decision:
    """PDP 决策入口: 构造 policy_input 后逐条评估规则, 算出布尔 allow。

    user:        会话用户 (id / groups / expires_at_ns)
    user_scopes: 会话被授予的 scope 集合
    args:        本次调用参数 (含 resource path)
    env:         平台注入的运行时事实 (ABAC)

    返回 Decision(allow=bool, ...), 没有中间态。
    """
    # 把 user_scopes 注入 user.groups, 供 scope 规则评估
    u = dict(user)
    u["groups"] = list(set(user.get("groups", [])) | set(user_scopes or ()))

    pi = build_policy_input(u, tool_name, args or {}, env or {})
    for rule in RULES:
        if rule["cond"](pi):
            return Decision(rule["allow"], rule["reason"], rule["name"])
    return Decision(False, "无默认规则, 拒绝", "none")
