# -*- coding: utf-8 -*-
"""
模拟运行入口 —— 演示两层模型:

  第 1 层 授权 (PDP): 布尔 allow/deny
      - 未授权工具 -> deny
      - write_file 是否满足文档 Rego 四条件 (engineering组+fs.write+路径/workspace/+TTL) -> allow/deny
      - ABAC 风控 -> deny
  第 2 层 流程 (Agent/PEP, 按工具 L 危险度标签):
      - L0/L1/L2 -> 直接执行
      - L3/L4    -> 人工确认
      - L5       -> 多因素 + 双人复核

运行: python main.py  (交互式, 会等待你输入 y/n)
"""
import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

import time
from audit import AuditLogger
from approval import ApprovalHandler
from agent import Agent
from policy import LEVELS, TOOL_REGISTRY


def section(t):
    print("\n" + "=" * 62)
    print(t)
    print("=" * 62)


def run():
    audit = AuditLogger()
    approval = ApprovalHandler()
    agent = Agent(audit, approval)

    sid, tid = "session-001", "trace-001"

    # ---- 场景 1: 授权通过 + L1 直接执行 ----
    section("场景 1 [授权allow] L1 只读查询 order.query -> 直接执行")
    agent.set_session_user({"id": "alice", "groups": ["engineering", "order:read"],
                            "expires_at_ns": time.time_ns() + 10**12})
    print("结果:", agent.execute_tool("order.query", {"order_id": "A1001"}, sid, tid))

    # ---- 场景 2: 授权 deny (无权限) ----
    section("场景 2 [授权deny] 无 order:refund 权限 -> 拒绝")
    agent.set_session_user({"id": "alice", "groups": ["engineering", "order:read"],
                            "expires_at_ns": time.time_ns() + 10**12})
    print("结果:", agent.execute_tool("order.refund", {"order_id": "A1001", "amount": 99.0}, sid, tid))

    # ---- 场景 3: 授权allow + L3 人工确认 ----
    section("场景 3 [allow+L3] 发通知 notify.user -> 人工确认")
    agent.set_session_user({"id": "alice", "groups": ["engineering", "notify:send"],
                            "expires_at_ns": time.time_ns() + 10**12})
    print("结果:", agent.execute_tool("notify.user", {"user_id": "u_42", "text": "您的订单已受理"}, sid, tid))

    # ---- 场景 4: 授权allow + L5 多因素 ----
    section("场景 4 [allow+L5] 退款 order.refund -> 多因素 + 双人复核")
    agent.set_session_user({"id": "alice", "groups": ["engineering", "order:refund"],
                            "expires_at_ns": time.time_ns() + 10**12})
    print("结果:", agent.execute_tool("order.refund", {"order_id": "A1001", "amount": 99.0}, sid, tid))

    # ---- 场景 5: write_file 满足文档 Rego 四条件 -> allow (R4) ----
    section("场景 5 [规则allow] write_file 满足 engineering+fs.write+/workspace/+TTL -> 放行")
    agent.set_session_user({"id": "alice", "groups": ["engineering"],
                            "expires_at_ns": time.time_ns() + 10**12})
    print("结果:", agent.execute_tool(
        "write_file", {"path": "/workspace/foo.py", "content": "print(1)"}, sid, tid))

    # ---- 场景 6: write_file 路径不在 /workspace -> deny (R5 default deny) ----
    section("场景 6 [规则deny] write_file 路径在 /tmp/ 不在 /workspace/ -> 拒绝")
    print("结果:", agent.execute_tool(
        "write_file", {"path": "/tmp/evil.py", "content": "rm -rf /"}, sid, tid))

    # ---- 场景 7: ABAC 风控 -> 授权 deny (R3) ----
    section("场景 7 [授权deny-ABAC] order.refund 在异地高速移动 -> 拒绝")
    agent.set_session_user({"id": "alice", "groups": ["engineering", "order:refund"],
                            "expires_at_ns": time.time_ns() + 10**12})
    agent.policy_context.update(travel_velocity_kmh=950.0, user_ip_geo="US-NewYork")
    print("结果:", agent.execute_tool("order.refund", {"order_id": "A1001", "amount": 99.0}, sid, tid))

    # ---- 场景 8: LLM 伪造 environment 绕过风控 -> 被忽略仍拒 ----
    section("场景 8 [防伪造] LLM 伪造 environment 想绕过 ABAC -> 仍拒绝")
    forged = {"session_travel_velocity_kmh": 0.0, "user_ip_geo": "CN-Shanghai"}
    print("结果:", agent.execute_tool("order.refund", {"order_id": "A1001", "amount": 99.0},
                                      sid, tid, llm_claims=forged))

    # ---- 审计摘要 ----
    section(f"审计摘要: 共 {len(audit)} 条事件")
    print("工具 -> 等级 -> 流程:")
    for name, c in TOOL_REGISTRY.items():
        print(f"  {name:<16} L{c['level']}  {LEVELS[c['level']]['handling']}")
    print()

run()
